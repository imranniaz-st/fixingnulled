<?php

return [
    'name' => 'Updater',
    'installed_version' => env('APP_VERSION', '1.0'),
];


