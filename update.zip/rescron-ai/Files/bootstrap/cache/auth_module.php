<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\Auth\\Providers\\AuthServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\Auth\\Providers\\AuthServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);