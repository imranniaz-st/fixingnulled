<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\AutoWithdrawal\\Providers\\AutoWithdrawalServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\AutoWithdrawal\\Providers\\AutoWithdrawalServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);