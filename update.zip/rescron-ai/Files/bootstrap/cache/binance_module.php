<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\Binance\\Providers\\BinanceServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\Binance\\Providers\\BinanceServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);