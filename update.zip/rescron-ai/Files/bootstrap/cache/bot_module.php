<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\Bot\\Providers\\BotServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\Bot\\Providers\\BotServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);