<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\Deposit\\Providers\\DepositServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\Deposit\\Providers\\DepositServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);