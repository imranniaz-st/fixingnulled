<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\Kyc\\Providers\\KycServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\Kyc\\Providers\\KycServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);