<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\Updater\\Providers\\UpdaterServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\Updater\\Providers\\UpdaterServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);