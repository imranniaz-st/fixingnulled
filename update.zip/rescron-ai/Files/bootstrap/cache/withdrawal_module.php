<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\Withdrawal\\Providers\\WithdrawalServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\Withdrawal\\Providers\\WithdrawalServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);